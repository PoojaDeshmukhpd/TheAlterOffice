package com.example.appeventtracker.worker

import android.content.Context
import android.util.Log
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.appeventtracker.data.local.EventDao
import com.example.appeventtracker.delegates.EventIngestionDelegate
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlin.coroutines.cancellation.CancellationException

@HiltWorker
class EventWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted workerParams: WorkerParameters,
    private val eventDao: EventDao,
    private val ingestionDelegate: EventIngestionDelegate
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        Log.d(TAG, "Worker started. workId=$id")

        return try {
            val now = System.currentTimeMillis()

            val recoveredCount = eventDao.recoverStaleEvents(
                staleBefore = now - STALE_EVENT_TIMEOUT_MS,
                updatedAt = now
            )

            Log.d(TAG, "Recovered stale events. rows=$recoveredCount")

            processQueue()

            Log.d(TAG, "Queue processing completed. workId=$id")
            Result.success()
        } catch (exception: CancellationException) {
            Log.d(TAG, "Worker cancelled. workId=$id")
            throw exception
        } catch (exception: Exception) {
            Log.e(TAG, "Worker failed; WorkManager will retry", exception)
            Result.retry()
        }
    }


    private suspend fun processQueue() {
        while (!isStopped) {
            val nextEvent = eventDao.getNextEvent()

            if (nextEvent == null) {
                Log.d(TAG, "No eligible events remaining")
                break
            }

            val claimed = eventDao.claimEvent(
                eventId = nextEvent.id,
                updatedAt = System.currentTimeMillis()
            )

            if (claimed != 1) {
                Log.d(TAG, "Event ${nextEvent.id} was claimed elsewhere")
                continue
            }

            val event = eventDao.getEventById(nextEvent.id) ?: continue

            Log.d(
                TAG,
                "Processing event: id=${event.id}, type=${event.eventType}, " +
                        "retryCount=${event.retryCount}"
            )

            try {
                ingestionDelegate.ingest(event)

                eventDao.updateEventStatus(
                    eventId = event.id,
                    status = "PROCESSED",
                    retryCount = event.retryCount,
                    lastError = null,
                    updatedAt = System.currentTimeMillis()
                )

                Log.d(
                    TAG,
                    "Event processed successfully: id=${event.id}, " +
                            "type=${event.eventType}"
                )
            } catch (exception: CancellationException) {
                throw exception
            } catch (exception: Exception) {
                val nextRetryCount = event.retryCount + 1

                eventDao.updateEventStatus(
                    eventId = event.id,
                    status = "RETRYING",
                    retryCount = nextRetryCount,
                    lastError = exception.message ?: "Ingestion failed",
                    updatedAt = System.currentTimeMillis()
                )

                Log.e(
                    TAG,
                    "Event marked RETRYING: id=${event.id}, " +
                            "type=${event.eventType}, retryCount=$nextRetryCount",
                    exception
                )

            }
        }
    }


    private companion object {
        const val TAG = "EventWorker"
        const val STALE_EVENT_TIMEOUT_MS = 2 * 60 * 1000L
    }
}